import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import AutomaticBatching from "./Pages/AutomaticBatching";
import About from "./Pages/About";
import Profile from "./Pages/Profile";
import ErrorPage from "./Pages/ErrorPage";

function App() {
  return (
    <Router>
      <nav>
        <Link to="/" className="App-link"> Automatic Batching </Link>
        <Link to="/about" className="App-link"> About </Link>
        <Link to="/profile" className="App-link"> Profile </Link>
      </nav>
      <div style={{paddingBottom:'2rem'}}></div>
      <Routes>
        <Route path="/" element={<AutomaticBatching />} />
        <Route path="/about" element={<About />} />
        <Route path="/profile/:username" element={<Profile />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </Router>
  );
}

export default App;
