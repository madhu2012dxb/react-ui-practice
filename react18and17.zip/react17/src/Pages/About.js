import React from "react";

function About() {
  return <div>THIS IS THE ABOUT PAGE</div>;
}

export default About;
