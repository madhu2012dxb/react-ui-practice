import React, { useState,useEffect } from "react";
function randomIntFromInterval(min, max) { // min and max included
  return Math.floor(Math.random() * (max - min + 1) + min)
}
function AutomaticBatching() {
  const [firstName,setFirstName]=useState("Madhu");
  const [lastName,setLatNmae]=useState("Yannam");
  const [showName,setShowName]=useState(false);
  const [fullName,setFullName]=useState("Yannam");
  const [generateRandomNum,setGenerateRandomNum]=useState(false);

  const [randomNumber1,setRandomNumber1]=useState(1);
  const [randomNumber2,setRandomNumber2]=useState(2);
  const [randomNumber3,setRandomNumber3]=useState(3);

  const [product1,setProduct1]=useState("Product1");
  const [product2,setProduct2]=useState("Product2");
  const [product3,setProduct3]=useState("Product3");


  useEffect(()=>{
  if(generateRandomNum){
  setRandomNumber1(Math.random())
  setRandomNumber2(Math.random())
  setRandomNumber3(Math.random())
  }
    /*const id = setTimeout(() => {
        if(generateRandomNum){
            setRandomNumber1(Math.random())
            setRandomNumber2(Math.random())
            setRandomNumber3(Math.random())
            }
        }, 1000);
         return () => {
         clearTimeout(id)
         }*/

  },[generateRandomNum])
  
  const updateFirstName=(e)=>{
    setFirstName(e.target.value);
  }
  const updateLastName=(e)=>{
    setLatNmae(e.target.value);
  }
  const showFullName=(showName)=>{
    setShowName(!showName);
    setFullName(firstName+' '+lastName);
  }
  const geRandomProducts=()=>{
    fetch('https://dummyjson.com/products')
    .then(res => res.json())
    .then(json => {
    console.log('::json.products::',json.products)
     setProduct1(json.products[randomIntFromInterval(0,29)].title);
     setProduct2(json.products[randomIntFromInterval(0,29)].title);
     setProduct3(json.products[randomIntFromInterval(0,29)].title);
    })
  }
  console.log('::Render::')
  return <div style={{paddingLeft:'2rem'}}>
  <div>{showName && <>FullName:{fullName}</>}</div>
  <div>Random numbers: {product1}{` `}{product2}{` `}{product3}</div>
  <div>Random three products: {randomNumber1}{` `}{randomNumber2}{` `}{randomNumber3}</div>
  <div><input name="firstName" placeholder="First Name" onChange={(e)=>updateFirstName(e)} /></div>
  <div><input name="lastName" placeholder="Last Name" onChange={(e)=>updateLastName(e)} /></div>
  <div><button style={{marginTop:'1rem'}} onClick={()=>showFullName(showName)}>{!showName ?'Show Name':'Hide Name'}</button></div>
  <div><button style={{marginTop:'1rem'}} onClick={()=>setGenerateRandomNum(true)}>{'Generate Ranodm Numbers'}</button></div>
  <div><button style={{marginTop:'1rem'}} onClick={()=>geRandomProducts()}>{'Get First 3 Products'}</button></div>

  </div>
}

export default AutomaticBatching;
