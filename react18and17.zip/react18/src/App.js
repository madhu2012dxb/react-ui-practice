import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import AutomaticBatching from "./Pages/AutomaticBatching";
import UseIDHook from "./Pages/UseIDHook";
import Transition from "./Pages/Transition";
import UseDefer from "./Pages/UseDefer";
import SuspenseFallback from "./Pages/SuspenseFallback"
import WithoutTransition from "./Pages/WithoutTransition";
import ErrorPage from "./Pages/ErrorPage";

function App() {
  return (
    <Router>
      <nav>
        <Link to="/" className="App-link"> Automatic Batching </Link>
        <Link to="/useIDHook" className="App-link"> UseId Hook </Link>
        <Link to="/useDefer" className="App-link"> Use Deferred </Link>
        <Link to="/tranision" className="App-link"> Transition </Link>
        <Link to="/withoutTranision" className="App-link"> Without Transition </Link>
        <Link to="/suspense" className="App-link"> Suspense </Link>
      </nav>
      <div style={{paddingBottom:'2rem'}}></div>
      <Routes>
        <Route path="/" element={<AutomaticBatching />} />
        <Route path="/useIDHook" element={<UseIDHook />} />
        <Route path="/tranision" element={<Transition />} />
        <Route path="/useDefer" element={<UseDefer />} />
        <Route path="/suspense" element={<SuspenseFallback />} />
        <Route path="/withoutTranision" element={<WithoutTransition />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </Router>
  );
}

export default App;
