import { useState, useEffect,Suspense } from 'react';
import useGetData from "./../useGetData";
const Products=()=>{
    const data = useGetData("https://dummyjson.com/products?limit=100");
    return (
        <div>
          {data &&
            data.products.map((product) => (
              <div key={product.id}>
                <h2>{product.title}</h2>
              </div>
            ))}
        </div>
      );
}
export default Products;