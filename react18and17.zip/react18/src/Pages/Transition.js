import { useState, useTransition } from 'react';
const dummyProducts = generateProducts();
function ProductList({ products }) {
 // const deferredProducts = useDeferredValue(products);
  return (
    <ul>
      {products.map((product) => (
        <li>{product}</li>
      ))}
    </ul>
  );
}
function generateProducts() {
  const products = [];
  for (let i = 0; i < 4000; i++) {
    products.push(`Product ${i+1}`);
  }
  return products;
}
function filterProducts(filterTerm) {
  if (!filterTerm) {
    return dummyProducts;
  }
  return dummyProducts.filter((product) => product.includes(filterTerm));
}

function Transition() {
  const [isPending, startTransition] = useTransition();
  const [filterTerm, setFilterTerm] = useState('');
  const [inputFilterTerm,setInputFilterTerm]=useState("");

  const filteredProducts = filterProducts(filterTerm);

  function updateFilterHandler(event) {
     setInputFilterTerm(event.target.value);
     startTransition(() => {
       setFilterTerm(event.target.value);
     });
  }
   return (
    <div id="app">
      <input type="text" onChange={updateFilterHandler} value={inputFilterTerm}/>
      {isPending && <p style={{color: 'green'}}>Updating List...</p>} 
      <ProductList products={filteredProducts} />
    </div>
  );
}
  
export default Transition;