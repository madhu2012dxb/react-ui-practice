import React, { useId } from "react";

import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';

function UseIDHook() {
  const id=useId();
  return <Form>
  <Row>
      <Col>
       <label htmlFor={"userName"+id}>Username</label>
       </Col>
       <Col>
       <input id={"userName"+id}/>
       </Col>
      </Row>

      <Row>
    <Col>
    
    <label htmlFor={"password"+id}>Password</label>
    </Col>
    <Col>
    <input id={"password"+id}/>
    </Col>
    </Row>
    </Form>
      
  
}

export default UseIDHook;
