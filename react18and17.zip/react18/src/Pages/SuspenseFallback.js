import { useState, useEffect,Suspense } from 'react';
import Products from "./Products"


function SuspenseFallback() {

   return (
    <div>
      <Suspense fallback="Loading...">
       <Products/>
     </Suspense>
    </div>
  );
}
  
export default SuspenseFallback;